<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class AdminPage extends BaseController
{
	public function index()
	{
		return view('template/admin');
	}

	//--------------------------------------------------------------------

}
// $2y$10$5zQ.3fVzkfcmxcqcRTr4yOYbNQk8FOBv7pr02zSIKIDAoHwQNIpV2 -> admin 
// $2y$10$VfYPnbD7swK/BOa55V6K/ezvZv/.ZFDVLGrUocNzP9PFlfEANMyry -> kasir
// $2y$10$9fb8mXQ9nte7axg.9ueMSerXf.eu9TslqGZQn09.4Ame4Cd0M7X/y -> koki
